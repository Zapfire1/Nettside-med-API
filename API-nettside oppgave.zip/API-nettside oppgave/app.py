from flask import Flask, render_template
import requests
import random

app = Flask(__name__)

@app.route("/")
def hjem():
    random_id = random.randint(1, 200)
    url = f"https://api.attackontitanapi.com/characters/{random_id}"
    
    response = requests.get(url)
    data = response.json()

    image = data.get("img")  # unngår crash hvis key mangler

    return render_template(
    "index.html",
    name=data.get("name"),
    image=data.get("img"),
    status=data.get("status"),
    gender=data.get("gender"),
    species=data.get("species")
)

@app.route("/catfact")
def catfact():
    url = "https://catfact.ninja/fact"
    response = requests.get(url)
    data = response.json()

    return render_template(
        "catfact.html",
        fact=data["fact"]
    )

app.run(debug=True)